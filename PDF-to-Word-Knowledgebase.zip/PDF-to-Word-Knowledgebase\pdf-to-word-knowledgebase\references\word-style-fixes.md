# Word Style and Native Editing Rules

Use this reference when the task depends on Word-specific behavior rather than plain document text generation.

## Default Word Behavior

By default for this skill:
- use the built-in cover page `花丝`
- only modify the cover title
- do not add page numbers

If the user later asks to change cover details or page numbering, handle those as explicit overrides.

## Cover Page Rules

Preferred path:
- use Word COM for native cover insertion when available

Default cover behavior:
- insert `花丝`
- update only the title field
- do not actively alter the other built-in cover components

Do not:
- replace the whole cover with a custom imitation unless native insertion is blocked
- strip built-in elements unless the user explicitly asks

## Page Number Rules

Default:
- no page numbers

If the user asks to add page numbers:
- prefer Word COM and section-aware footer editing
- if numbering should start from the body, create or reuse a body section and start numbering there

If the user asks to remove page numbers:
- delete footer page number fields
- clear any remaining numeric footer content if it only exists for page numbering

## Font Rules

The document should use `微软雅黑` for:
- title
- heading 1
- heading 2
- heading 3
- normal body text
- image captions

## Why `font.name` Alone Is Not Enough

Word may still display a different East Asian font in the style pane if the underlying OOXML keeps theme-based font mappings.

When needed, fix all of:
- `ascii`
- `hAnsi`
- `eastAsia`
- `cs`

And remove theme mappings such as:
- `asciiTheme`
- `hAnsiTheme`
- `eastAsiaTheme`
- `cstheme`

## OOXML Repair Rules

If `python-docx` does not preserve the intended Word style behavior:
- patch `word/styles.xml` directly
- update both paragraph styles and linked character styles where relevant

Typical targets:
- `Title`
- `Heading1`
- `Heading2`
- `Heading3`
- `TitleChar`
- `Heading1Char`
- `Heading2Char`
- `Heading3Char`
- `Normal`
- `docDefaults`

Preferred explicit values:
- `ascii = Microsoft YaHei`
- `hAnsi = Microsoft YaHei`
- `eastAsia = 微软雅黑`
- `cs = Microsoft YaHei`

## Caption Repair Rules

If caption text is corrupted, especially when `图` becomes `?`:
- rewrite the caption text explicitly
- use Unicode-safe insertion if the shell or terminal encoding is unreliable
- preserve caption order and numbering while repairing text

## Native Word Operations

Prefer Word COM for:
- built-in cover pages
- native footer page numbering
- section-aware pagination
- any workflow where Word UI behavior matters more than OOXML portability

Prefer `python-docx` for:
- building headings and paragraphs
- inserting images
- assigning most content
- lightweight revisions

Use OOXML patching as a fallback when:
- styles do not resolve correctly in Word
- theme font inheritance overrides visible font settings
- Word UI shows the wrong Chinese font despite prior edits
