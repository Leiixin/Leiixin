---
name: pdf-to-word-knowledgebase
description: Use this skill when converting training PDFs, PPT-export PDFs, or similar documents into structured Word knowledge-base documents, or when editing an existing Word document to fix cover pages, heading hierarchy, table of contents, image placement, image captions, numbering, fonts, page numbers, and Word style compatibility.
---

# PDF to Word Knowledgebase

## Overview

Use this skill to turn training-style PDFs into editable Word knowledge-base documents, or to continue revising an existing `.docx` after conversion. The goal is not raw format transfer. The goal is a Word document that is editable, structured, readable, and consistent with knowledge-base expectations.

Default output contract:
- Add the built-in Word cover page `花丝`.
- Only change the cover title by default unless the user asks for more.
- All visible text on the cover page must use `微软雅黑`.
- Do not actively change other built-in cover elements unless the user asks.
- Do not add page numbers unless the user explicitly asks.
- Keep the cover page and the table of contents on separate pages.
- Start the table of contents on a new page after the cover.
- Start the main body on a new page after the table of contents.
- Table of contents entries must not be bold.
- Rebuild the body as a knowledge-base structure, not a slide deck transcript.
- Use `1 / 1.1 / 1.1.1` heading hierarchy.
- Use `微软雅黑` for title, headings, body, and image captions.
- Do not keep summary paragraphs directly under level-1 or level-2 headings.

## When to Use

Use this skill when the user asks for any of the following:
- Convert a PDF into Word.
- Turn a training deck or PPT-export PDF into a knowledge-base document.
- Insert a Word cover page, TOC, images, or captions.
- Reorganize Word headings and numbering.
- Remove or add page numbers.
- Fix Word styles so headings really use `微软雅黑`.
- Reorder or repair image captions such as `图 1`, `图 2`, and so on.
- Continue revising a Word file after a previous conversion pass.

## Workflow Decision

1. Determine the document type.
- Text PDF: extract text directly.
- PPT-export PDF: extract text and page images, then rebuild by topic.
- Scan PDF: use OCR first if needed.

2. Determine the task type.
- New conversion: build a Word draft from the PDF.
- Existing Word revision: edit the `.docx` in place and preserve existing valid structure.

3. Choose the implementation path.
- Use `PyMuPDF` for page text and page image extraction.
- Use `python-docx` for document structure and content generation.
- Use Word COM when the task depends on native Word behaviors such as built-in covers or page numbering.
- If Word style settings do not stick, patch `.docx` OOXML directly.

## Core Workflow

1. Inspect the PDF or existing `.docx`.
- Check page count.
- Check whether text extraction is reliable.
- Identify whether pages are repeated topic slides rather than continuous prose.

2. Build or repair structure.
- Merge repeated slide pages into topic-based sections.
- Use level-1, level-2, and level-3 headings only when they reflect real structure.
- If a level-3 heading already exists and there are still label-like subitems under it, convert those subitems to bold body text instead of promoting them into deeper headings.
- Remove generic overview paragraphs under level-1 and level-2 headings.
- Keep business-useful source content as complete as practical during reconstruction.

3. Generate or edit the Word document.
- Apply Word heading styles instead of inventing custom paragraph conventions.
- Insert a TOC field if a TOC is required.
- Keep the cover, TOC, and main body on separate pages by default.
- Ensure TOC entries remain non-bold.
- Update Word style definitions themselves, not only the visible paragraph formatting.
- Insert page images under their corresponding content sections.
- Add image captions below the images.

4. Apply knowledge-base formatting rules.
- Use `微软雅黑` across title, headings, body, captions, and cover-page text.
- Use numbered body points `1、2、3、` for multi-item content.
- If there is only one item, do not number it.
- Do not use black bullet dots unless the user explicitly asks for them.

5. Apply Word-native polish.
- Default cover page is `花丝`.
- Only update the cover title by default.
- Force all visible cover-page text to `微软雅黑`.
- Do not add page numbers unless requested.

6. Verify the result.
- Check heading order.
- Check whether image captions are sequential.
- Check whether chapter cover images were wrongly retained.
- Check whether Word styles still map to `微软雅黑`.

## Document Reconstruction Rules

For detailed transformation rules, read [references/pdf-to-word-rules.md](references/pdf-to-word-rules.md).

High-level rules:
- Organize by topic, not by original slide or page order alone.
- Do not over-compress the source material during reconstruction.
- When converting PDF training material into a Word knowledge-base document, preserve business-useful content as fully as practical.
- The output may be reorganized for readability, but key operational content must not be omitted.
- Use level-1, level-2, and level-3 headings only when they reflect real structure.
- If a level-3 heading already exists and there are still label-like subitems under it, convert those subitems to bold body text instead of promoting them into deeper headings.
- Remove presentation-style filler and repeated transition text.
- Remove generic summary paragraphs directly under level-1 and level-2 headings unless the user explicitly asks to keep them.
- Keep image captions out of the TOC.
- Remove chapter cover images by default unless the user explicitly asks to keep them.

Chinese execution requirements:
- 内容整理要按主题重组，不能机械按原 PDF 页序逐页照搬。
- 正文内容不能过度概括，不能为了简洁把 PDF 里的有效信息删得太多。
- 对于每一页 PDF 中有业务价值的内容，整理成 Word 时应尽量完整落到正文，不要只保留一个简短概述。
- 可以重组顺序、合并重复内容，但不能因为重组而遗漏关键信息。
- 如果某一页 PPT 信息很多，应拆成多个二级或三级标题、正文分点、正文加粗标签等方式展开，而不是压缩成一两句。
- 一级、二级标题下默认不保留概述性总结段。
- 标题层级默认只使用 `1 / 1.1 / 1.1.1`。
- 如果三级标题下还有标签型内容，需要改为正文加粗，不再继续升标题。
- 要优先保留并展开这些信息：定义、口径、步骤、条件、规则、注意事项、示例、场景、模板字段、路径、时间点、监控要点、异常处理、例外说明。
- 图片应插在对应内容下方，不能集中堆到文末。
- 图片标题不进目录。
- 章节封面图默认删除，除非用户明确要求保留。
- 最终 Word 文档应以“知识库可复用”为目标，保证后续读者不看原 PDF 也能理解主要操作内容。

## Word Rules

For detailed Word handling and style repair guidance, read [references/word-style-fixes.md](references/word-style-fixes.md).

High-level rules:
- Built-in cover page: `花丝`.
- Change only the cover title unless instructed otherwise.
- All visible cover-page text must use `微软雅黑`.
- Do not keep mixed cover fonts, theme-default fonts, or fallback East Asian fonts on the cover page.
- Default page numbers: off.
- Cover page and TOC must be separated.
- TOC starts on a new page after the cover.
- Main body starts on a new page after the TOC.
- TOC entries must not be bold.
- This applies to TOC level 1, level 2, and level 3 entries.
- After updating the TOC field, recheck `TOC 1 / TOC 2 / TOC 3` styles and rendered TOC lines to ensure they are still non-bold.
- Do not only format paragraphs visually. Update the Word style definitions themselves so the document can be maintained later from the style pane.
- After formatting is finalized, the following Word styles must be updated in the style pane to match the actual document formatting.

Required style definitions:

1. `正文`
- Font: `微软雅黑`
- Font size: `11 pt`
- Bold: `No`
- Line spacing: `1.15`
- Space before: `0 pt`
- Space after: `0 pt`

2. `标题 1`
- Font: `微软雅黑`
- Font size: `16 pt`
- Bold: `Yes`
- Line spacing: `1.15`
- Space before: `12 pt`
- Space after: `4 pt`

3. `标题 2`
- Font: `微软雅黑`
- Font size: `14 pt`
- Bold: `Yes`
- Line spacing: `1.15`
- Space before: `8 pt`
- Space after: `4 pt`

4. `标题 3`
- Font: `微软雅黑`
- Font size: `12 pt`
- Bold: `Yes`
- Line spacing: `1.15`
- Space before: `8 pt`
- Space after: `4 pt`

5. `目录标题`
- Font: `微软雅黑`
- Bold: `No`

6. `TOC 1`
- Font: `微软雅黑`
- Bold: `No`
- Line spacing: `1.15`
- Space before: `0 pt`
- Space after: `0 pt`

7. `TOC 2`
- Font: `微软雅黑`
- Bold: `No`
- Line spacing: `1.15`
- Space before: `0 pt`
- Space after: `0 pt`

8. `TOC 3`
- Font: `微软雅黑`
- Bold: `No`
- Line spacing: `1.15`
- Space before: `0 pt`
- Space after: `0 pt`

Chinese execution requirements:
- 不仅要修改段落外观，还要同步修改 Word “样式”栏中的样式定义本身。
- `正文` 样式必须维护为：微软雅黑、11 磅、不加粗、1.15 倍行距、段前 0 磅、段后 0 磅。
- `标题 1` 样式必须维护为：微软雅黑、16 磅、加粗、1.15 倍行距、段前 12 磅、段后 4 磅。
- `标题 2` 样式必须维护为：微软雅黑、14 磅、加粗、1.15 倍行距、段前 8 磅、段后 4 磅。
- `标题 3` 样式必须维护为：微软雅黑、12 磅、加粗、1.15 倍行距、段前 8 磅、段后 4 磅。
- 如果三级标题下还有标签型内容，需要改为正文加粗，不再继续升标题。
- 目录标题必须为微软雅黑、不加粗。
- `TOC 1 / TOC 2 / TOC 3` 样式必须维护为：微软雅黑、不加粗、1.15 倍行距、段前 0 磅、段后 0 磅。
- 文档整理完成后，样式栏中的上述样式必须与正文实际显示效果一致，方便后续直接通过样式栏统一修改。
- 如果刷新目录会覆盖目录格式，刷新后需要再次检查并修正目录标题、`TOC 1 / TOC 2 / TOC 3` 的样式定义和实际目录条目格式。
- Heading hierarchy: `Heading 1`, `Heading 2`, `Heading 3`.
- Fonts must be explicit enough that Word does not silently substitute another East Asian font.

## Editing Existing Word Files

When revising an existing `.docx`:
- Prefer targeted edits over full regeneration if the requested change is narrow.
- Preserve content that already matches the rules.
- Reorder captions by actual appearance order if numbering drifted.
- Remove page numbers by deleting footer page number fields, not merely hiding them.
- If a caption loses the `图` character due to encoding or path issues, rewrite it explicitly using Unicode-safe text.

## Validation Checklist

Before finishing, verify:
- Cover page exists if default behavior is in scope.
- Cover title is correct.
- All visible cover-page text uses `微软雅黑`.
- Cover page and TOC are not on the same page.
- TOC and main body are not on the same page.
- TOC entries are not bold.
- `TOC 1 / TOC 2 / TOC 3` styles and rendered TOC lines remain non-bold after TOC refresh.
- `正文 / 标题 1 / 标题 2 / 标题 3 / 目录标题 / TOC 1 / TOC 2 / TOC 3` style definitions are updated in the style pane and match the actual document formatting.
- If label-like content appears under a level-3 heading, it is formatted as bold body text rather than promoted into a deeper heading.
- Content is not over-compressed and still preserves the key business-useful information from the PDF.
- No unwanted summary paragraph sits under level-1 or level-2 headings.
- Body uses `1、2、3、` numbering for multi-item sections.
- Single-item sections are not artificially numbered.
- Images are placed with the correct content.
- Captions appear below images.
- Captions are sequential.
- Chapter cover images are removed unless requested.
- Page numbers are absent by default.
- Styles resolve to `微软雅黑`.

## References

- Content restructuring rules: [references/pdf-to-word-rules.md](references/pdf-to-word-rules.md)
- Word and style repair rules: [references/word-style-fixes.md](references/word-style-fixes.md)
