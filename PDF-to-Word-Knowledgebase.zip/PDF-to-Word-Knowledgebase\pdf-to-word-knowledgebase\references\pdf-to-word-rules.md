# PDF to Word Knowledgebase Rules

Use this reference when the user wants a training PDF converted into a structured Word knowledge-base document rather than a page-for-page transcript.

## Target Output

The target document should be:
- editable in Word
- structured for long-term maintenance
- readable without the original slides
- consistent in headings, numbering, captions, and fonts

## Reconstruction Principles

### 1. Rebuild by topic, not by slide sequence

Training PDFs often repeat a page title across multiple pages. Do not mirror that repetition mechanically. Merge pages that belong to the same topic into one structured section.

Good:
- `2.1 下单前准备`
- `2.1.1 ERP 账号权限申请`
- `2.1.2 客户端下载与登录信息`
- `2.1.3 系统配置确认`

Bad:
- `第 4 页`
- `第 5 页`
- `第 6 页`

### 2. Remove presentation-style summary sentences

Do not keep overview sentences directly below level-1 or level-2 headings unless the user explicitly wants them. In knowledge-base output, these usually add little value and make the document feel padded.

Remove patterns like:
- `本章整理……`
- `本节用于……`
- `本部分主要说明……`

### 3. Preserve only operational content

Prefer to keep:
- step-by-step procedures
- paths
- conditions
- rules
- notes
- examples
- exceptions

Prefer to delete or collapse:
- decorative filler
- slide transition text
- redundant summaries
- repeated slogan text

## Heading Rules

Use three levels by default:
- level 1: `1`
- level 2: `1.1`
- level 3: `1.1.1`

Do not create deeper levels unless the user explicitly needs them.

Use real topic structure:
- chapter / domain
- subtopic / procedure group
- concrete operation / rule / subtype

## Body Formatting Rules

### Numbering

Use `1、2、3、` for multi-item content.

Use this for:
- steps
- rules
- conditions
- notes
- examples when there is more than one

If there is only one item:
- write it as a normal sentence or paragraph
- do not prefix `1、`

Do not use:
- black bullet dots
- mixed bullet styles
- inconsistent numbering inside the same document

### Paragraph Strategy

Keep paragraphs short and task-oriented.

Preferred forms:
- `进入路径：……`
- `前提条件：……`
- `操作步骤：……`
- `注意事项：……`

## Image Rules

### Image Placement

Insert each page image under the content it supports.

Do not:
- place all images at the end by default
- separate images from the sections they explain

### Chapter Cover Images

If a PDF contains chapter cover slides such as `PART 01`, `PART 02`, remove those cover images by default unless the user asks to keep them.

### Captions

Put captions below images.

Caption style should be:
- understated
- readable
- `微软雅黑`

Caption numbering should follow actual appearance order in the Word document, not original PDF page numbers if they diverge.

## TOC Rules

Insert a TOC when requested or when the document structure is large enough to benefit from one.

TOC should include:
- heading 1
- heading 2
- heading 3

TOC should not include:
- image captions
- appendix-like image labels
- helper notes

## Default Post-Conversion Edits

These were repeatedly required and should be treated as default review checks:
- images belong under related content
- headings use `1 / 1.1 / 1.1.1`
- level-1 and level-2 summaries are removed
- body lists use `1、2、3、`
- single-item content is not numbered
- image captions are below images
- image captions are renumbered if needed
- chapter cover images are removed
- `图` captions are repaired if encoding corruption occurs
